cd /home/fcbox/.elon/app/
python3 restartIpc.py --count 100